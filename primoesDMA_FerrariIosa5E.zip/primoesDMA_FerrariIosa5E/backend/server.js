const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');

// Istanziazione del server Express
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Rotta POST per recuperare i To-Do
app.post('/get-todos', async (req, res) => {
    const apiUrl = 'https://dummyjson.com/todos';

    try {
        // Recupera i dati dall'API
        const response = await axios.get(apiUrl);
        const todos = response.data.todos;

        // Invia i To-Do al frontend
        res.json({ todos });
    } catch (error) {
        console.error("Errore durante il recupero dei To-Do:", error.message);
        res.status(500).json({ error: "Impossibile recuperare i To-Do" });
    }
});

// Avvio del server backend
app.listen(port, '0.0.0.0', () => {
    console.log(`Server backend in esecuzione su http://localhost:${port}`);
});
