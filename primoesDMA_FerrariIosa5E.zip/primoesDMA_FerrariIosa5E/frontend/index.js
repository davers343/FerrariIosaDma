$(document).ready(function () {
    $('#fetchTodos').click(function () {
        // Mostra lo spinner di caricamento
        $('#loading').show();
        $('#todoContainer').html(''); // Svuota il contenitore dei To-Do

        // Effettua la richiesta al backend
        $.post('http://localhost:3000/get-todos', {}, function (data) {
            // Nascondi lo spinner di caricamento
            $('#loading').hide();

            // Mostra solo i primi 9 To-Do
            let todosHtml = '';
            const limitedTodos = data.todos.slice(0, 9); // Estrae i primi 9 To-Do

            limitedTodos.forEach((todo) => {
                todosHtml += `
                    <div class="todo-card">
                        <h3>${todo.todo}</h3>
                        <p><strong>Completato:</strong> ${todo.completed ? "Sì" : "No"}</p>
                    </div>
                `;
            });
            $('#todoContainer').html(todosHtml);
        }).fail(function () {
            // Nascondi lo spinner di caricamento e mostra un errore
            $('#loading').hide();
            $('#todoContainer').html('<p>Errore nel recupero dei To-Do.</p>');
        });
    });
});
